package me.jellysquid.mods.sodium.client.render.chunk.format;

public enum ChunkMeshAttribute {
    POSITION,
    COLOR,
    TEXTURE,
    LIGHT,
    NORMAL,
    TANGENT,
    MID_TEX_COORD,
    BLOCK_ID
}
