package me.jellysquid.mods.sodium.client.render.chunk.format;

public class ChunkModelOffset {
    public float x, y, z;

    public void set(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
