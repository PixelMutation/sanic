package me.jellysquid.mods.sodium.client.util.task;

public interface CancellationSource {
    boolean isCancelled();
}
